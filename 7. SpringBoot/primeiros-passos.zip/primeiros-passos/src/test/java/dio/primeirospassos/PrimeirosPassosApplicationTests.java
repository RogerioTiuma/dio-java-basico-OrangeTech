package dio.primeirospassos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeirosPassosApplicationTests {

	@Test
	void contextLoads() {
	}

}
